public class Principal {

    public static void main(String[] args) {
        Recursividade r = new Recursividade();
        System.out.println(r.testesFatorial());
        System.out.println(r.testesFibonacci());
        System.out.println(r.testesMultiplicacao());
        System.out.println(r.testesDivisao());
        System.out.println(r.testesResto());
        System.out.println(r.testesTamanho());
    }
}
