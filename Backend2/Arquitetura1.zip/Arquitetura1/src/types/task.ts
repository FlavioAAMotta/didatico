export type task = {
   id: string,
   title: string,
   description: string,
   deadline: string,
   authorId: string
}