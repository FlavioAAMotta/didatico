import { v4 } from "uuid"

export const generateId = (): string => v4()